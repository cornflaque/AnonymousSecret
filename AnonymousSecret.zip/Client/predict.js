$("#slider").roundSlider({
    width: 22,
    radius: 100,
    value: 0,
    lineCap: "round",
    sliderType: "min-range",
    startAngle: 90,
    max: "15",
    mouseScrollAction: true
});
